public class Rectangle {
    private int length;
    private int breath;

    public Rectangle(int length, int breath) {
        this.length = length;
        this.breath = breath;
    }

    public int getLength() {
        return length;
    }

    public int getBreath() {
        return breath;
    }
    public void Area(){
        int area = length * breath;
        System.out.println("Area of an Rectangle : "+area);
    }
    public void perimeter(){
        int perimeter = 2 * (length + breath);
        System.out.println("Perimeter of an Rectangle : "+perimeter);
    }
}
