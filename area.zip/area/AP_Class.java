import java.util.Scanner;

public class AP_Class {
    public static void main(String[] args){
        Scanner sc = new Scanner(System.in);
        System.out.println("Enter length and breath of an rectangle : ");
        int length = sc.nextInt();
        int breath = sc.nextInt();
        Rectangle rectangle = new Rectangle(length, breath);
        rectangle.Area();
        rectangle.perimeter();

        Square square = new Square(length , breath);
        square.Area();
        square.perimeter();
    }
}
