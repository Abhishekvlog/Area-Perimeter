public class Square extends Rectangle {

    public Square(int length, int breath) {
        super(length, breath);
    }
    public void Area(){
        int area = getLength() * getLength();
        System.out.println("Area of an Square : "+area);
    }
    public void Perimeter(){
        int perimeter = 4 * getLength();
        System.out.println("Perimeter of an Square : "+perimeter);
    }
}
